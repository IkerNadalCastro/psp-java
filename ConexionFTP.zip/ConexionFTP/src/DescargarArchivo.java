import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

public class DescargarArchivo {
	
	public static void main(String[] args) {
		
		String servidor = "192.168.102.200"; 
		int puerto = 21; //puerto por defecto para ftp
		String usuario = "uftp"; 
		String contraseña = "alumno"; 
		
		FTPClient cliente = new FTPClient();
			
			try {
				
				cliente.connect(servidor, puerto);
				System.out.println("conectado");
				
				if(cliente.login(usuario, contraseña)) 
					System.out.println("Login correcto");
				else 
					System.out.println("Login incorrecto");
				
				cliente.setFileType(FTP.BINARY_FILE_TYPE); 
				File archivoLocal = new File("FicheroDescargado.txt"); 
				String archivoRemoto = "aaa/descargame.txt"; 
				
				OutputStream os = new FileOutputStream(archivoLocal); 
				System.out.println("Comenzando la descarga...");
				
				boolean descargado = cliente.retrieveFile(archivoRemoto, os);
				os.close();
				
				if(descargado) 
					System.out.println("Archivo enviado");
				else 
					System.out.println("Error en la transmisión");
				
			} catch (IOException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			} finally {
				
				if (cliente.isConnected()) {
					
					try {
						cliente.logout(); 
						cliente.disconnect();
						
						System.out.println("conexion finalizada");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				
			}
		
	}

}
