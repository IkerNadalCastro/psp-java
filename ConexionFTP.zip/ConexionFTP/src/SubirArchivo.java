import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

public class SubirArchivo {

	public static void main(String[] args) {
		
		String servidor = "192.168.102.200"; 
		int puerto = 21; //puerto por defecto para ftp
		String usuario = "uftp"; 
		String contraseña = "alumno"; 
		
		FTPClient cliente = new FTPClient();
			
			try {
				
				cliente.connect(servidor, puerto);
				System.out.println("conectado");
				
				if(cliente.login(usuario, contraseña)) 
					System.out.println("Login correcto");
				else 
					System.out.println("Login incorrecto");
				
				cliente.setFileType(FTP.BINARY_FILE_TYPE); 
				File archivoLocal = new File("Iker.txt"); 
				String archivoRemoto = "ficheroIker.txt"; 
				
				InputStream is = new FileInputStream(archivoLocal); 
				System.out.println("Comenzando la subida...");
				
				boolean terminado = cliente.storeFile(archivoRemoto, is);
				is.close();
				
				if(terminado) 
					System.out.println("Archivo enviado");
				else 
					System.out.println("Error en la transmisión");
				
			} catch (IOException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			} finally {
				
				if (cliente.isConnected()) {
					
					try {
						cliente.logout(); 
						cliente.disconnect();
						
						System.out.println("conexion finalizada");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				
			}

	}
	
}
